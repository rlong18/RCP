require 'test_helper'

class GotoControllerTest < ActionDispatch::IntegrationTest
  test "should get first" do
    get goto_first_url
    assert_response :success
  end

end
