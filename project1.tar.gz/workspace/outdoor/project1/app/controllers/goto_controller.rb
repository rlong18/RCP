class GotoController < ApplicationController
  def first
  end
  def second
  end 
  def third
  end
end
