Rails.application.routes.draw do
  get 'goto/first'
  root 'goto#first'
  get 'goto/second'
  root 'goto#second'
  get 'goto/third'
  root 'goto#third'
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
